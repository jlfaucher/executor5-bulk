This folder contains the rex script BuildandUploadDocs.rex
used by the Jenkins framwork to 
(i) build the ooRexx documentation (if amended) using the existing documentation
build tools, and
(ii) upload the ooRexx documentation to sourceforge.

The script will check and build/upload only documents that have been
amended. Further instructions and requirements are embedded in the script.

Once launched the script will set up its own working environment. 

This script is intended for use by the developers only. Do not try this at home ;-)
